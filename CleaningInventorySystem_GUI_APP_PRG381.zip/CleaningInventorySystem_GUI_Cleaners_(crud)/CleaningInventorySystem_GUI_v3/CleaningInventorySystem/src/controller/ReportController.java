package controller;

import dao.ReportDAO;
import view.ReportView;
import view.DashboardView;

public class ReportController {

    private ReportView view;
    private ReportDAO dao;

    public ReportController(ReportView view) {

        this.view = view;
        dao = new ReportDAO();

        view.btnLoad.addActionListener(e -> {

            loadReport();

        });

        view.btnBack.addActionListener(e -> {

            new DashboardView().setVisible(true);

            view.dispose();

        });

    }

    private void loadReport() {

        String tableName =
                view.cmbReport.getSelectedItem().toString();

        dao.loadReport(tableName, view.tblReport);

    }

}