
package controller;

import dao.UserDao;
import util.DatabaseException;
import view.LoginView;
import view.DashboardView;

import javax.swing.*;

public class LoginController {

    private LoginView view;
    private UserDao dao;

    public LoginController(
            LoginView view) {

        this.view = view;

        dao = new UserDao();

        view.btnLogin.addActionListener(e -> {

            login();

        });
    }

    private void login() {

        String username =
            view.txtUsername.getText();

        String password =
            String.valueOf(
                view.txtPassword.getPassword()
            );
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Please enter both username and password", "Validation error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try{
            boolean success = dao.login(username, password);
            if(success) {

            JOptionPane.showMessageDialog(
                view,
                "Login Successful",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
            );

            DashboardView dashboard =
                new DashboardView();

            dashboard.setVisible(true);

            view.dispose();

            } else {

                JOptionPane.showMessageDialog(
                view,
                "Invalid Username or Password",
                "Login Failed",
                JOptionPane.ERROR_MESSAGE
                );
            }
            
        } catch (DatabaseException e) {
            JOptionPane.showMessageDialog(view, "Database error during authentication: " + e.getMessage(),
                    "System Error",
                    JOptionPane.ERROR_MESSAGE);
        }   
    }
}