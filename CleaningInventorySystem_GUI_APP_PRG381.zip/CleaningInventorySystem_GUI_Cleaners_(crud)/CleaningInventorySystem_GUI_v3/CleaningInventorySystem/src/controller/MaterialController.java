package controller;

import dao.MaterialDAO;
import view.MaterialsView;
import model.Material;
import util.DatabaseException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class MaterialController {

    private MaterialsView view;
    private MaterialDAO dao;

    public MaterialController(MaterialsView view) {
        this.view = view;
        dao = new MaterialDAO();

        loadTable();
        
        //Attaching event listeners
        initEventHandlers();
    }

    private void loadTable() {
        try{
            DefaultTableModel model = (DefaultTableModel)view.tblMaterials.getModel();
        dao.loadMaterials(model);
        
        // Apply visual low-stock highlighting
        applyLowStockHighlighting();

        // Trigger low-stock warning alert if any items need reordering
        checkLowStockAlert();
        } catch (DatabaseException ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        

    }
    
    private void initEventHandlers(){
        //Adding button action
        view.btnAdd.addActionListener(e -> performAdd());
        
        //Update button action
        view.btnUpdate.addActionListener(e -> performUpdate());
        
        //Delete button action
        view.btnDelete.addActionListener(e -> performDelete());
        
        //clear button action
        view.btnClear.addActionListener(e -> clearFields());
        
        //Back to dashboard action
        view.btnBack.addActionListener(e ->{
            int confirm = JOptionPane.showConfirmDialog(
            view,
            "Are you sure you want to go back?",
            "Confirm",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            view.dispose();
        }        
        });

        
        //table row click action - populate input fields from selected row
        view.tblMaterials.addMouseListener(new MouseAdapter(){
        @Override
        public void mouseClicked(MouseEvent e){
        int selectedRow = view.tblMaterials.getSelectedRow();
        if (selectedRow != -1){
            view.txtMaterialID.setText(view.tblMaterials.getValueAt(selectedRow,0).toString());
            view.txtMaterialName.setText(view.tblMaterials.getValueAt(selectedRow,1).toString());
            view.txtQuantity.setText(view.tblMaterials.getValueAt(selectedRow,2).toString());
            view.txtReorderLevel.setText(view.tblMaterials.getValueAt(selectedRow,3).toString());
            view.txtSupplierID.setText(view.tblMaterials.getValueAt(selectedRow,4).toString());
                }
            }
        });   
    }
    
    //CRUD Create
    private void performAdd(){
        if(!validateInputs(false)){
            return;
        }
        try{
            Material material = new Material();
            material.setMaterialName(view.txtMaterialName.getText().trim());
            material.setQuantity(Integer.parseInt(view.txtQuantity.getText().trim()));
            material.setReorderLevel(Integer.parseInt(view.txtReorderLevel.getText().trim()));
            material.setSupplierID(Integer.parseInt(view.txtSupplierID.getText().trim()));
            
            if(dao.addMaterial(material)){
                JOptionPane.showMessageDialog(view, "Material added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable();
                clearFields();
            }
            else{
                JOptionPane.showMessageDialog(view, "Failed to add material. Verify database state.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (DatabaseException ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage(), "Database Exception", JOptionPane.ERROR_MESSAGE);
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(view, "Invalid numeric input values.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //CRUD UPDATE
    private void performUpdate(){
        if(!validateInputs(true)){
            return;
        }
        
        try{
            Material material = new Material();
            material.setMaterialID(Integer.parseInt(view.txtMaterialID.getText().trim()));
            material.setMaterialName(view.txtMaterialName.getText().trim());
            material.setQuantity(Integer.parseInt(view.txtQuantity.getText().trim()));
            material.setReorderLevel(Integer.parseInt(view.txtReorderLevel.getText().trim()));
            material.setSupplierID(Integer.parseInt(view.txtSupplierID.getText().trim()));
            
            if(dao.updateMaterial(material)){
                JOptionPane.showMessageDialog(view, "Material updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable();
                clearFields();
            }
            else{
                JOptionPane.showMessageDialog(view, "Failed to update material.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (DatabaseException ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage(), "Database Exception", JOptionPane.ERROR_MESSAGE);
        }
        catch (NumberFormatException ex){
            JOptionPane.showMessageDialog(view, "Invalid numeric values detected", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //CRUD UPDATE
    private void performDelete(){
        String idText = view.txtMaterialID.getText().trim();
        if(idText.isEmpty()){
            JOptionPane.showMessageDialog(view, "Please select or specify a Meterial ID to delete", "Validation Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(view, "Are you sure you want to delete this material?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION){
            try{
                int materialID = Integer.parseInt(idText);
                if(dao.deleteMaterial(materialID)){
                    JOptionPane.showMessageDialog(view, "Material deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadTable();
                    clearFields();
                }
                else{
                    JOptionPane.showMessageDialog(view, "Failed to delete material. ID might not exist", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (DatabaseException ex) {
            JOptionPane.showMessageDialog(view, ex.getMessage(), "Deletion Blocked", JOptionPane.WARNING_MESSAGE);
            }
            catch (NumberFormatException ex){
            JOptionPane.showMessageDialog(view, "Invalid Material ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }   
    }
    
    private void clearFields(){
        view.txtMaterialID.setText("");
        view.txtMaterialName.setText("");
        view.txtQuantity.setText("");
        view.txtReorderLevel.setText("");
        view.txtSupplierID.setText("");
        view.tblMaterials.clearSelection();
    }
    
    //Validation and Exception Handling rules
    private boolean validateInputs(boolean isUpdate){
        //If you are updating, the Material ID is needed to target the right record
        if(isUpdate && view.txtMaterialID.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(view, "Material ID is missing. Select a material to edit", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String name = view.txtMaterialName.getText().trim();
        String qtyText = view.txtQuantity.getText().trim();
        String reorderText = view.txtReorderLevel.getText().trim();
        String supplierText = view.txtSupplierID.getText().trim();
        
        //No fields should be empty
        if(name.isEmpty() || qtyText.isEmpty() || reorderText.isEmpty() || supplierText.isEmpty()){
            JOptionPane.showMessageDialog(view, "All fields (Name, Quantity, Reorder Level, Supplier ID) must be filled", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        //Type and value checks
        int quantity, reorderLevel, supplierID;
        try{
            quantity = Integer.parseInt(qtyText);
            if(quantity<0){
                JOptionPane.showMessageDialog(view, "Quantity cannot be negative", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(view, "Quantitiy must be a valid whole number", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try{
            reorderLevel = Integer.parseInt(reorderText);
            if(reorderLevel<0){
                JOptionPane.showMessageDialog(view, "ReorderLevel cannot be negative", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(view, "Reorder Level must be a valid whole number", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try{
            supplierID = Integer.parseInt(supplierText);
            if(supplierID<0){
                JOptionPane.showMessageDialog(view, "Supplier ID must be a positive number", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(view, "Supplier ID must be a valid whole number", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try{
            if (!dao.supplierExists(supplierID)){
            JOptionPane.showMessageDialog(view, "Supplier ID " + supplierID + " does not exist in the database. Please provide a valid Supplier ID.","Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
            }
        } catch (DatabaseException e) {
            JOptionPane.showMessageDialog(view, "Failed to verify Supplier ID: " + e.getMessage(), "Databse Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    //Highlighting logic - Shows low stock rows with a warning colour
    private void applyLowStockHighlighting() {
        view.tblMaterials.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                if(!isSelected) {
                    try {
                        //Columns: ID = 0, Name = 1, Qty = 2, ReorderLevel = 3, SupplierID = 4
                        int qty = Integer.parseInt(table.getValueAt(row, 2).toString());
                        int reorderLevel = Integer.parseInt(table.getValueAt(row, 3).toString());
                        
                        if (qty <= reorderLevel) {
                            c.setBackground(new java.awt.Color(255, 204, 204));
                            c.setBackground(java.awt.Color.BLACK);
                        } else {
                            c.setBackground(java.awt.Color.WHITE);
                            c.setBackground(java.awt.Color.BLACK);
                        }
                    } catch (Exception e) {
                        c.setBackground(java.awt.Color.WHITE);
                        c.setBackground(java.awt.Color.BLACK);
                    }
                }
                return c;
            }
        });
        view.tblMaterials.repaint();
    }
    
    //Alert logic: Displays a notification dialog if low stock items exist
    private void checkLowStockAlert() {
        try{
            int lowStockCount = dao.getLowStockCount();
            if (lowStockCount > 0) {
                JOptionPane.showMessageDialog(
                view,
                "Attention: There are " + lowStockCount + " material(s) at or below reorder level!",
                "Low Stock Warning!",
                JOptionPane.WARNING_MESSAGE);
            }
        } catch (DatabaseException e) {
            JOptionPane.showMessageDialog(view, 
                    "Error checking low stock count: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        } 
    }
}
