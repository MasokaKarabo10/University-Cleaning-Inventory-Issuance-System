package controller;

import dao.DashboardDAO;
import view.CleanersView;
import view.DashboardView;
import view.LoginView;
import view.MaterialsView;
import view.SupplierView;
import view.IssuanceView;
import view.ReportView;

public class DashboardController {

    private DashboardView view;
    private DashboardDAO dao;

    public DashboardController(DashboardView view) {

        this.view = view;
        dao = new DashboardDAO();

        loadStatistics();

        // Open Materials Module
        view.btnMaterials.addActionListener(e -> {
            new MaterialsView().setVisible(true);
        });

        // Open Cleaners Module
        view.btnCleaners.addActionListener(e -> {
            new CleanersView().setVisible(true);
        });

        // Open Suppliers Module
        view.btnSuppliers.addActionListener(e -> {
            new SupplierView().setVisible(true);
        });
        
        view.btnIssuances.addActionListener(e -> {
    new IssuanceView().setVisible(true);
});
        
        view.btnReports.addActionListener(e -> {

    new ReportView().setVisible(true);

});

        // Logout
        view.btnLogout.addActionListener(e -> {
            new LoginView().setVisible(true);
            view.dispose();
        });

    }

    private void loadStatistics() {

        int totalMaterials = dao.getTotalMaterials();
        view.lblTotalMaterials.setText(String.valueOf(totalMaterials));

        int totalCleaners = dao.getTotalCleaners();
        view.lblTotalCleaners.setText(String.valueOf(totalCleaners));

        int lowStock = dao.getLowStockCount();
        view.lblLowStock.setText(String.valueOf(lowStock));

        int totalIssuances = dao.getTotalIssuances();
        view.lblTotalIssuances.setText(String.valueOf(totalIssuances));
    }
}