package controller;

import dao.IssuanceDAO;
import javax.swing.table.DefaultTableModel;
import view.IssuanceView;
import view.DashboardView;

public class IssuanceController {

    private IssuanceView view;
    private IssuanceDAO dao;

    public IssuanceController(IssuanceView view) {

        this.view = view;
        dao = new IssuanceDAO();

        loadTable();

        // Issue
        view.btnIssue.addActionListener(e -> {
            issueMaterial();
        });

        // Update
        view.btnUpdate.addActionListener(e -> {
            updateIssuance();
        });

        // Delete
        view.btnDelete.addActionListener(e -> {
            deleteIssuance();
        });

        // Clear
        view.btnClear.addActionListener(e -> {
            clearFields();
        });

        // Table Row Selection
        view.tblIssuances.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {

                fillFields();

            }

        });
        
        view.btnBack.addActionListener(e -> {

    new DashboardView().setVisible(true);

    view.dispose();

});

    }

    private void loadTable() {

        DefaultTableModel model =
                (DefaultTableModel) view.tblIssuances.getModel();

        dao.loadIssuances(model);

    }

    private void issueMaterial() {

        int cleanerID =
                Integer.parseInt(view.txtCleanerID.getText());

        int materialID =
                Integer.parseInt(view.txtMaterialID.getText());

        int quantityIssued =
                Integer.parseInt(view.txtQuantityIssued.getText());

        String issueDate =
                view.txtIssueDate.getText();

        dao.issueMaterial(
                cleanerID,
                materialID,
                quantityIssued,
                issueDate);

        loadTable();
        clearFields();

    }

    private void updateIssuance() {

        dao.updateIssuance(

                Integer.parseInt(view.txtIssuanceID.getText()),
                Integer.parseInt(view.txtCleanerID.getText()),
                Integer.parseInt(view.txtMaterialID.getText()),
                Integer.parseInt(view.txtQuantityIssued.getText()),
                view.txtIssueDate.getText()

        );

        loadTable();
        clearFields();

    }

    private void deleteIssuance() {

        dao.deleteIssuance(

                Integer.parseInt(view.txtIssuanceID.getText())

        );

        loadTable();
        clearFields();

    }

    private void fillFields() {

        int row = view.tblIssuances.getSelectedRow();

        if (row == -1)
            return;

        view.txtIssuanceID.setText(
                view.tblIssuances.getValueAt(row, 0).toString());

        view.txtCleanerID.setText(
                view.tblIssuances.getValueAt(row, 1).toString());

        view.txtMaterialID.setText(
                view.tblIssuances.getValueAt(row, 2).toString());

        view.txtQuantityIssued.setText(
                view.tblIssuances.getValueAt(row, 3).toString());

        view.txtIssueDate.setText(
                view.tblIssuances.getValueAt(row, 4).toString());

    }

    private void clearFields() {

        view.txtIssuanceID.setText("");
        view.txtCleanerID.setText("");
        view.txtMaterialID.setText("");
        view.txtQuantityIssued.setText("");
        view.txtIssueDate.setText("");

    }

}