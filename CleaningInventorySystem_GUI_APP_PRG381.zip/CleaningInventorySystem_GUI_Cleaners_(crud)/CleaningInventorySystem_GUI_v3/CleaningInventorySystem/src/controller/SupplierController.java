package controller;

import dao.SupplierDAO;
import model.Supplier;
import view.SupplierView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 *
 * @author Admin
 */
public class SupplierController {
    
    private SupplierView view;
    private SupplierDAO dao;
    
    public SupplierController(SupplierView view) {
        this.view = view;
        this.dao = new SupplierDAO();
        
        //load data into table
        loadTable();
        
        //register event listeners - buttons and table clicks
        initEventHandlers();
    }
    
    
    private void loadTable() {
        DefaultTableModel model = (DefaultTableModel)view.tblSuppliers.getModel();
        dao.loadSuppliers(model);
    }
    
    private void initEventHandlers(){
        //Adding button action
        view.btnAdd.addActionListener(e -> performAdd());
        
        //Update button action
        view.btnUpdate.addActionListener(e -> performUpdate());
        
        //Delete button action
        view.btnDelete.addActionListener(e -> performDelete());
        
        //clear button action
        view.btnClear.addActionListener(e -> clearFields());
        
        //Back to dashboard action
        view.btnBack.addActionListener(e ->{
            int confirm = JOptionPane.showConfirmDialog(
            view,
            "Are you sure you want to go back?",
            "Confirm",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            view.dispose();
        }        
        });
        
        //table row click action - populate input fields from selected row
        view.tblSuppliers.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                int selectedRow = view.tblSuppliers.getSelectedRow();
                if (selectedRow != -1){
                    view.txtSupplierID.setText(view.tblSuppliers.getValueAt(selectedRow, 0).toString());
            
                    Object nameObj = view.tblSuppliers.getValueAt(selectedRow, 1);
                    view.txtSupplierName.setText(nameObj != null ? nameObj.toString() : "");
            
                    Object contactObj = view.tblSuppliers.getValueAt(selectedRow, 2);
                    view.txtContactPerson.setText(contactObj != null ? contactObj.toString() : "");
            
                 Object phoneObj = view.tblSuppliers.getValueAt(selectedRow, 3);
                 view.txtPhoneNumber.setText(phoneObj != null ? phoneObj.toString() : "");

                  Object emailObj = view.tblSuppliers.getValueAt(selectedRow, 4);
                  view.txtEmail.setText(emailObj != null ? emailObj.toString() : "");
                }
            }
        });
    }
    
    //Create
    private void performAdd() {
        if (!validateInputs(false)) {
            return;
        }

        Supplier supplier = new Supplier();
        supplier.setSupplierName(view.txtSupplierName.getText().trim());
        supplier.setContactPerson(view.txtContactPerson.getText().trim());
        supplier.setPhoneNumber(view.txtPhoneNumber.getText().trim());
        supplier.setEmail(view.txtEmail.getText().trim());

        if (dao.addSupplier(supplier)) {
            JOptionPane.showMessageDialog(view, "Supplier added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            loadTable();
            clearFields();
        } else {
            JOptionPane.showMessageDialog(view, "Failed to add supplier. Check database connection.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //UPDATE
    
    private void performUpdate() {
        if (!validateInputs(true)) {
            return;
        }

        try {
            Supplier supplier = new Supplier();
            supplier.setSupplierID(Integer.parseInt(view.txtSupplierID.getText().trim()));
            supplier.setSupplierName(view.txtSupplierName.getText().trim());
            supplier.setContactPerson(view.txtContactPerson.getText().trim());
            supplier.setPhoneNumber(view.txtPhoneNumber.getText().trim());
            supplier.setEmail(view.txtEmail.getText().trim());

            if (dao.updateSupplier(supplier)) {
                JOptionPane.showMessageDialog(view, "Supplier updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable();
                clearFields();
            } else {
                JOptionPane.showMessageDialog(view, "Failed to update supplier.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(view, "Invalid Supplier ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //DELETE
    private void performDelete() {
        String idText = view.txtSupplierID.getText().trim();
        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Please select or specify a Supplier ID to delete.", "Validation Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(view, "Are you sure you want to delete this supplier?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int supplierID = Integer.parseInt(idText);
                if (dao.deleteSupplier(supplierID)) {
                    JOptionPane.showMessageDialog(view, "Supplier deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadTable();
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(view, "Failed to delete supplier. The supplier may be linked to existing materials.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Invalid Supplier ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    //CLEAR
    private void clearFields() {
        view.txtSupplierID.setText("");
        view.txtSupplierName.setText("");
        view.txtContactPerson.setText("");
        view.txtPhoneNumber.setText("");
        view.txtEmail.setText("");
        view.tblSuppliers.clearSelection();
    }
    
    //Input validations
    private boolean validateInputs(boolean isUpdate) {
        //needed for Update operation
        if (isUpdate && view.txtSupplierID.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(view, "Supplier ID is missing. Select a supplier to edit", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String name = view.txtSupplierName.getText().trim();
        String phone = view.txtPhoneNumber.getText().trim();
        String email = view.txtEmail.getText().trim();
        
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Supplier name is required", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (!phone.isEmpty() && !phone.matches("^[0-9+\\-\\s()]{7,20}$")) {
            JOptionPane.showMessageDialog(view, "Please enter a valid phone number (digits only, 7-20 characters)", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (!email.isEmpty() && !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(view, "Please enter a valid email address (e.g., name@example.com)", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
}
