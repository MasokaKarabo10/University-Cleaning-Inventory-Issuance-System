package controller;

import dao.CleanerDAO;
import model.Cleaner;
import view.CleanersView;
import view.DashboardView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CleanerController {

    private CleanersView view;
    private CleanerDAO dao;

    public CleanerController(CleanersView view) {
        this.view = view;
        this.dao = new CleanerDAO();

        loadTable();
        initEventHandlers();
        view.btnBack.addActionListener(e -> {

    new DashboardView().setVisible(true);

    view.dispose();

});
    }

    private void loadTable() {
        DefaultTableModel model =
                (DefaultTableModel) view.tblCleaners.getModel();

        dao.loadCleaners(model);
    }

    private void initEventHandlers() {

        view.btnAdd.addActionListener(e -> addCleaner());

        view.btnUpdate.addActionListener(e -> updateCleaner());

        view.btnDelete.addActionListener(e -> deleteCleaner());

        view.btnClear.addActionListener(e -> clearFields());

        view.tblCleaners.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                int row = view.tblCleaners.getSelectedRow();

                if (row != -1) {

                    view.txtCleanerID.setText(view.tblCleaners.getValueAt(row,0).toString());
                    view.txtFirstName.setText(view.tblCleaners.getValueAt(row,1).toString());
                    view.txtLastName.setText(view.tblCleaners.getValueAt(row,2).toString());
                    view.txtPhoneNumber.setText(view.tblCleaners.getValueAt(row,3).toString());

                }
            }
        });
    }

    private void addCleaner() {

        if(!validateInput())
            return;

        Cleaner cleaner = new Cleaner();

        cleaner.setFirstName(view.txtFirstName.getText().trim());
        cleaner.setLastName(view.txtLastName.getText().trim());
        cleaner.setPhoneNumber(view.txtPhoneNumber.getText().trim());

        if(dao.addCleaner(cleaner)){

            JOptionPane.showMessageDialog(view,"Cleaner added successfully.");

            loadTable();

            clearFields();

        }else{

            JOptionPane.showMessageDialog(view,"Failed to add cleaner.");

        }

    }

    private void updateCleaner(){

        if(view.txtCleanerID.getText().trim().isEmpty()){

            JOptionPane.showMessageDialog(view,"Select a cleaner first.");

            return;
        }

        if(!validateInput())
            return;

        Cleaner cleaner = new Cleaner();

        cleaner.setCleanerID(Integer.parseInt(view.txtCleanerID.getText()));

        cleaner.setFirstName(view.txtFirstName.getText().trim());

        cleaner.setLastName(view.txtLastName.getText().trim());

        cleaner.setPhoneNumber(view.txtPhoneNumber.getText().trim());

        if(dao.updateCleaner(cleaner)){

            JOptionPane.showMessageDialog(view,"Cleaner updated successfully.");

            loadTable();

            clearFields();

        }else{

            JOptionPane.showMessageDialog(view,"Update failed.");

        }

    }

    private void deleteCleaner(){

        if(view.txtCleanerID.getText().trim().isEmpty()){

            JOptionPane.showMessageDialog(view,"Select a cleaner first.");

            return;
        }

        int confirm = JOptionPane.showConfirmDialog(

                view,

                "Delete this cleaner?",

                "Confirm",

                JOptionPane.YES_NO_OPTION

        );

        if(confirm==JOptionPane.YES_OPTION){

            int id=Integer.parseInt(view.txtCleanerID.getText());

            if(dao.deleteCleaner(id)){

                JOptionPane.showMessageDialog(view,"Cleaner deleted.");

                loadTable();

                clearFields();

            }else{

                JOptionPane.showMessageDialog(view,"Delete failed.");

            }

        }

    }

    private void clearFields(){

        view.txtCleanerID.setText("");

        view.txtFirstName.setText("");

        view.txtLastName.setText("");

        view.txtPhoneNumber.setText("");

        view.tblCleaners.clearSelection();

    }

    private boolean validateInput(){

        if(view.txtFirstName.getText().trim().isEmpty()){

            JOptionPane.showMessageDialog(view,"First Name is required.");

            return false;

        }

        if(view.txtLastName.getText().trim().isEmpty()){

            JOptionPane.showMessageDialog(view,"Last Name is required.");

            return false;

        }

        return true;

    }

}