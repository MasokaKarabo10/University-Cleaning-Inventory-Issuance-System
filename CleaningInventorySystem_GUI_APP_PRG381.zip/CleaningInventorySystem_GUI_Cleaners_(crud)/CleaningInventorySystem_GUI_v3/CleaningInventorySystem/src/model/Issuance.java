package model;

public class Issuance {

    private int issuanceID;
    private int cleanerID;
    private int materialID;
    private int quantityIssued;
    private String issueDate;

    public int getIssuanceID() {
        return issuanceID;
    }

    public void setIssuanceID(int issuanceID) {
        this.issuanceID = issuanceID;
    }

    public int getCleanerID() {
        return cleanerID;
    }

    public void setCleanerID(int cleanerID) {
        this.cleanerID = cleanerID;
    }

    public int getMaterialID() {
        return materialID;
    }

    public void setMaterialID(int materialID) {
        this.materialID = materialID;
    }

    public int getQuantityIssued() {
        return quantityIssued;
    }

    public void setQuantityIssued(int quantityIssued) {
        this.quantityIssued = quantityIssued;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }
}