package model;

public class Supplier {
    
    private int supplierID;
    private String supplierName;
    private String contactPerson;
    private String phoneNumber;
    private String email;
    
    //getters and setters
    public int getSupplierID(){
        return supplierID;
    }
    
    public void setSupplierID(int supplierID){
        this.supplierID = supplierID;
    }
    
    public String getSupplierName(){
        return supplierName;
    }
    
    public void setSupplierName(String supplierName){
        this.supplierName = supplierName;
    }
    
    public String getContactPerson(){
        return contactPerson;
    }
    
    public void setContactPerson(String contactPerson){
        this.contactPerson = contactPerson;
    }
    
    public String getPhoneNumber(){
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
}
