package dao;

import util.DBConnection;
import util.DatabaseException;
import model.Material;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class MaterialDAO {

    public void loadMaterials(
            DefaultTableModel model) throws DatabaseException {

        String sql =
        "SELECT * FROM Materials "
      + "ORDER BY MaterialID";

        try (
            Connection con =
                DBConnection.getConnection();

            PreparedStatement ps =
                con.prepareStatement(sql);

            ResultSet rs =
                ps.executeQuery()
        ) {

            model.setRowCount(0);

            while(rs.next()) {

                model.addRow(
                    new Object[] {

                        rs.getInt("MaterialID"),
                        rs.getString("MaterialName"),
                        rs.getInt("Quantity"),
                        rs.getInt("ReorderLevel"),
                        rs.getInt("SupplierID")

                    }
                );
            }

        } catch(SQLException e) {

            throw new DatabaseException("Failed to load materials from the database", e);
        }
    }
    
    //Create - add a new material to the database
    public boolean addMaterial(Material material) throws DatabaseException {
        String sql = "INSERT INTO Materials (MaterialName, Quantity, ReorderLevel, SupplierID) VALUES (?, ?, ?, ?)";
        Connection con = null;
        try{
            con = DBConnection.getConnection(); 
            con.setAutoCommit(false);
            
            try(PreparedStatement ps = con.prepareStatement(sql)){
                ps.setString(1, material.getMaterialName());
                ps.setInt(2, material.getQuantity());
                ps.setInt(3, material.getReorderLevel());
                ps.setInt(4, material.getSupplierID());
                
                int rowsAffected = ps.executeUpdate();
                con.commit();
                return rowsAffected > 0;
            }
        } catch(SQLException e){
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { /* log rollback failure */ }
                }
                
                //POSTGRESQL Foreign key violation code: 23503
                if ("23503".equals(e.getSQLState())) {
                    throw new DatabaseException("Supplier ID " + material.getSupplierID() + " does not exist in the system", e);
                }
                throw new DatabaseException("Failed to add material due to a database error", e);
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException e) {
                    /* close connection */
                }
            }
        }  
    }
    
    //Update - modify an existing material record
    public boolean updateMaterial(Material material) throws DatabaseException {
        String sql = "UPDATE Materials SET MaterialName = ?, Quantity = ?, ReorderLevel = ?, SupplierID = ? WHERE MaterialID = ?";
        try(
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
            ){
            ps.setString(1, material.getMaterialName());
            ps.setInt(2, material.getQuantity());
            ps.setInt(3, material.getReorderLevel());
            ps.setInt(4, material.getSupplierID());
            ps.setInt(5, material.getMaterialID());
        
            return ps.executeUpdate()>0;
        } catch(SQLException e){
            if ("23503".equals(e.getSQLState())) {
                throw new DatabaseException("Cannot update material: The specified Supplier ID does not exist", e);
            }
            throw new DatabaseException("Failed to update material record", e);
        }
    }

    //DELETE - remove a material record from the database
    public boolean deleteMaterial(int materialID) throws DatabaseException {
        String sql = "DELETE FROM Materials WHERE MaterialID = ?";
        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, materialID);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            //Check if material is referenced in Issuances table
            if ("23503".equals(e.getSQLState())) {
                throw new DatabaseException("Cannot delete material: Linked to past issuane records", e);
            }
            throw new DatabaseException("Failed to delete material record", e);
        }
    }

    //VALIDATION - check if the SupplierID exists in the database before inserting
    public boolean supplierExists(int supplierID) throws DatabaseException {
        String sql = "SELECT 1 FROM Suppliers WHERE SupplierID = ?";
        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, supplierID);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new DatabaseException("Database error verifying supplier presence.", e);
        }
    }
    
    //Reporting - load only the low stock idems
    public void loadLowStockMaterials(DefaultTableModel model) {
        String sql = "SELECT * FROM MAterials WHERE Quantity <= ReorderLevel ORDER BY MaterialID";
        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[] {
                    rs.getInt("MaterialID"),
                    rs.getString("MaterialName"),
                    rs.getInt("Quantity"),
                    rs.getInt("ReorderLevel"),
                    rs.getInt("SupplierID")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Report helper - get count of low stock items for alerts
    public int getLowStockCount() throws DatabaseException {
       String sql = "SELECT COUNT(*) AS LowCount FROM Materials WHERE Quantity <= ReorderLevel";
        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            if(rs.next()) {
                return rs.getInt("LowCount");
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to calculate low stock statistics",e);
        }
        return 0;
    }
}
