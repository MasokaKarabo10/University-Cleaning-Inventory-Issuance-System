package dao;

import util.DBConnection;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class IssuanceDAO {

    public void loadIssuances(DefaultTableModel model) {

        String sql =
            "SELECT * FROM Issuances ORDER BY IssuanceID";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[]{

                    rs.getInt("IssuanceID"),
                    rs.getInt("CleanerID"),
                    rs.getInt("MaterialID"),
                    rs.getInt("QuantityIssued"),
                    rs.getDate("IssueDate")

                });

            }

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
    public void issueMaterial(int cleanerID,
                          int materialID,
                          int quantityIssued,
                          String issueDate) {

    String insertSQL =
        "INSERT INTO Issuances "
      + "(CleanerID, MaterialID, QuantityIssued, IssueDate) "
      + "VALUES (?, ?, ?, ?)";

    String updateSQL =
        "UPDATE Materials "
      + "SET Quantity = Quantity - ? "
      + "WHERE MaterialID = ?";

    try (

        Connection con = DBConnection.getConnection()

    ) {

        con.setAutoCommit(false);

        PreparedStatement psInsert =
            con.prepareStatement(insertSQL);

        psInsert.setInt(1, cleanerID);
        psInsert.setInt(2, materialID);
        psInsert.setInt(3, quantityIssued);
        psInsert.setDate(4, Date.valueOf(issueDate));

        psInsert.executeUpdate();

        PreparedStatement psUpdate =
            con.prepareStatement(updateSQL);

        psUpdate.setInt(1, quantityIssued);
        psUpdate.setInt(2, materialID);

        psUpdate.executeUpdate();

        con.commit();

    } catch (Exception e) {

        e.printStackTrace();

    }

}
    public void updateIssuance(int issuanceID,
                           int cleanerID,
                           int materialID,
                           int quantityIssued,
                           String issueDate) {

    String sql =
        "UPDATE Issuances "
      + "SET CleanerID=?, "
      + "MaterialID=?, "
      + "QuantityIssued=?, "
      + "IssueDate=? "
      + "WHERE IssuanceID=?";

    try (

        Connection con = DBConnection.getConnection();

        PreparedStatement ps =
            con.prepareStatement(sql)

    ) {

        ps.setInt(1, cleanerID);
        ps.setInt(2, materialID);
        ps.setInt(3, quantityIssued);
        ps.setDate(4, Date.valueOf(issueDate));
        ps.setInt(5, issuanceID);

        ps.executeUpdate();

    } catch(Exception e) {

        e.printStackTrace();

    }

}
    public void deleteIssuance(int issuanceID) {

    String sql =
        "DELETE FROM Issuances "
      + "WHERE IssuanceID=?";

    try (

        Connection con =
            DBConnection.getConnection();

        PreparedStatement ps =
            con.prepareStatement(sql)

    ) {

        ps.setInt(1, issuanceID);

        ps.executeUpdate();

    } catch(Exception e) {

        e.printStackTrace();

    }

}
}