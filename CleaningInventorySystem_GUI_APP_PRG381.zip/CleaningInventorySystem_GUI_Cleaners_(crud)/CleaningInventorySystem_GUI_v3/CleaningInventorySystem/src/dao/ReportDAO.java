package dao;

import util.DBConnection;
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ReportDAO {

    public void loadReport(String tableName, JTable table) {

        DefaultTableModel model = new DefaultTableModel();

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM " + tableName;

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(sql);

            ResultSetMetaData meta = rs.getMetaData();

            int columns = meta.getColumnCount();

            for (int i = 1; i <= columns; i++) {

                model.addColumn(meta.getColumnName(i));

            }

            while (rs.next()) {

                Object[] row = new Object[columns];

                for (int i = 1; i <= columns; i++) {

                    row[i - 1] = rs.getObject(i);

                }

                model.addRow(row);

            }

            table.setModel(model);

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}