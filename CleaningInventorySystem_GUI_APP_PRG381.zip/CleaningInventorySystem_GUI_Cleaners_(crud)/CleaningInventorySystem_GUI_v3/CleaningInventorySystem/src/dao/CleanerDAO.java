package dao;

import util.DBConnection;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import model.Cleaner;

public class CleanerDAO {

    public void loadCleaners(DefaultTableModel model) {

        String sql =
            "SELECT * FROM Cleaners ORDER BY CleanerID";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[]{

                    rs.getInt("CleanerID"),
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("PhoneNumber")

                });

            }

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
     public boolean addCleaner(Cleaner cleaner) {

        String sql = "INSERT INTO Cleaners (FirstName, LastName, PhoneNumber) VALUES (?, ?, ?)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, cleaner.getFirstName());
            ps.setString(2, cleaner.getLastName());
            ps.setString(3, cleaner.getPhoneNumber());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();
            return false;

        }
    }
    public boolean updateCleaner(model.Cleaner cleaner) {

    String sql = "UPDATE Cleaners SET FirstName = ?, LastName = ?, PhoneNumber = ? WHERE CleanerID = ?";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(sql)
    ) {

        ps.setString(1, cleaner.getFirstName());
        ps.setString(2, cleaner.getLastName());
        ps.setString(3, cleaner.getPhoneNumber());
        ps.setInt(4, cleaner.getCleanerID());

        return ps.executeUpdate() > 0;

    } catch (SQLException e) {

        e.printStackTrace();
        return false;

    }
}public boolean deleteCleaner(int cleanerID) {

    String sql = "DELETE FROM Cleaners WHERE CleanerID = ?";

    try (
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(sql)
    ) {

        ps.setInt(1, cleanerID);

        return ps.executeUpdate() > 0;

    } catch (SQLException e) {

        e.printStackTrace();
        return false;

    }
}
    
}