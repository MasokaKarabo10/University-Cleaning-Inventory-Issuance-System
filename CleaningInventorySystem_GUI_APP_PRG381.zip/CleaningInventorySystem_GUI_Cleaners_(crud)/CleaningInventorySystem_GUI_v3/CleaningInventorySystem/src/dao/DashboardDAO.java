package dao;

import util.DBConnection;
import java.sql.*;

public class DashboardDAO {

    public int getTotalMaterials() {

        String sql =
            "SELECT COUNT(*) FROM Materials";

        try {

            Connection con =
                DBConnection.getConnection();

            if (con == null) {

                System.out.println(
                    "Connection is null"
                );

                return 0;
            }

            PreparedStatement ps =
                con.prepareStatement(sql);

            ResultSet rs =
                ps.executeQuery();

            if (rs.next()) {

                return rs.getInt(1);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
        

        return 0;
    }
    
    public int getTotalCleaners() {

    String sql =
        "SELECT COUNT(*) FROM Cleaners";

    try {

        Connection con =
            DBConnection.getConnection();

        if(con == null){
            return 0;
        }

        PreparedStatement ps =
            con.prepareStatement(sql);

        ResultSet rs =
            ps.executeQuery();

        if(rs.next()){
            return rs.getInt(1);
        }

    } catch(Exception e){

        e.printStackTrace();
    }

    return 0;
}
    public int getLowStockCount() {

    String sql =
        "SELECT COUNT(*) FROM Materials "
      + "WHERE Quantity <= ReorderLevel";

    try {

        Connection con =
            DBConnection.getConnection();

        if(con == null){
            return 0;
        }

        PreparedStatement ps =
            con.prepareStatement(sql);

        ResultSet rs =
            ps.executeQuery();

        if(rs.next()){
            return rs.getInt(1);
        }

    } catch(Exception e){

        e.printStackTrace();
    }

    return 0;
}
    public int getTotalIssuances() {

    String sql =
        "SELECT COUNT(*) FROM Issuances";

    try {

        Connection con =
            DBConnection.getConnection();

        if(con == null){
            return 0;
        }

        PreparedStatement ps =
            con.prepareStatement(sql);

        ResultSet rs =
            ps.executeQuery();

        if(rs.next()){
            return rs.getInt(1);
        }

    } catch(Exception e){

        e.printStackTrace();
    }

    return 0;
}
}