package dao;
import util.DBConnection;
import model.Supplier;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class SupplierDAO {
    
    //Loading all suppliers into a table model
    public void loadSuppliers(DefaultTableModel model){
        String sql = "SELECT * FROM Suppliers ORDER BY SupplierID";
        try(
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ){
            model.setRowCount(0);
            while (rs.next()){
                model.addRow(new Object[] {
                    rs.getInt("SupplierID"),
                    rs.getString("SupplierName"),
                    rs.getString("ContactPerson"),
                    rs.getString("PhoneNumber"),
                    rs.getString("Email")
                });
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    //Adding a new supplier
    public boolean addSupplier(Supplier supplier){
        String sql = "INSERT INTO Suppliers (SupplierName, ContactPerson, PhoneNumber, Email) VALUES (?, ?, ?, ?)";
        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
        ) {
            ps.setString(1, supplier.getSupplierName());
            ps.setString(2, supplier.getContactPerson());
            ps.setString(3, supplier.getPhoneNumber());
            ps.setString(4, supplier.getEmail());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //Update - modify an existing supplier
    public boolean updateSupplier(Supplier supplier) {
        String sql = "UPDATE Suppliers SET SupplierName = ?, ContactPerson = ?, PhoneNumber = ?, Email = ? WHERE SupplierID = ?";
        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
        ) {
            ps.setString(1, supplier.getSupplierName());
            ps.setString(2, supplier.getContactPerson());
            ps.setString(3, supplier.getPhoneNumber());
            ps.setString(4, supplier.getEmail());
            ps.setInt(5, supplier.getSupplierID());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    //Delete
    public boolean deleteSupplier(int SupplierID) {
        String sql = "DELETE FROM Suppliers WHERE SupplierID = ?";
        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
        ) {
            ps.setInt(1, SupplierID);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
