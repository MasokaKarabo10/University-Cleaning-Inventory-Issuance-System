package dao;

import util.DBConnection;
import util.DatabaseException;
import java.sql.*;

public class UserDao {

    public boolean login(String username,String password) throws DatabaseException {

        String sql =
        "SELECT * FROM Users "
      + "WHERE Username = ? "
      + "AND Password = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs =
                ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {

            throw new DatabaseException("Authentication failed due to a database connection issue", e);

        }
    }
}