package components;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class ImageAvatar extends JComponent {

    private Icon icon;
    private int borderSize = 0;

    public Icon getIcon() {
        return icon;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
        repaint();
    }

    public int getBorderSize() {
        return borderSize;
    }

    public void setBorderSize(int borderSize) {
        this.borderSize = borderSize;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics grphcs) {
        if (icon == null) {
            return; // Nothing to draw
        }

        int width = getWidth();
        int height = getHeight();
        
        // Ensure we have valid dimensions
        if (width <= 0 || height <= 0) {
            return;
        }

        int diameter = Math.min(width, height);
        int x = (width - diameter) / 2;
        int y = (height - diameter) / 2;
        
        int border = borderSize * 2;
        int innerDiameter = diameter - border;
        
        if (innerDiameter <= 0) {
            return; // Border is too large
        }

        // Get the image from the icon
        Image image = toImage(icon);
        if (image == null) {
            return;
        }

        // Create a circular clipping mask
        Rectangle size = getAutoSize(icon, innerDiameter);
        BufferedImage img = new BufferedImage(innerDiameter, innerDiameter, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2_img = img.createGraphics();
        
        // Enable anti-aliasing for smooth circle
        g2_img.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Create circular mask
        g2_img.fillOval(0, 0, innerDiameter, innerDiameter);
        
        // Apply the mask
        Composite composite = g2_img.getComposite();
        g2_img.setComposite(AlphaComposite.SrcIn);
        g2_img.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        
        // Draw the image inside the circle
        g2_img.drawImage(image, size.x, size.y, size.width, size.height, null);
        g2_img.setComposite(composite);
        g2_img.dispose();

        // Draw on the component
        Graphics2D g2 = (Graphics2D) grphcs;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw border if specified
        if (borderSize > 0) {
            g2.setColor(getForeground());
            g2.fillOval(x, y, diameter, diameter);
        }

        // Draw background if opaque
        if (isOpaque()) {
            g2.setColor(getBackground());
            g2.fillOval(x + borderSize, y + borderSize, innerDiameter, innerDiameter);
        }

        // Draw the masked image
        g2.drawImage(img, x + borderSize, y + borderSize, null);
        
        super.paintComponent(grphcs);
    }

    /**
     * Calculates the optimal size and position for the image to fill the circle
     * while maintaining aspect ratio
     */
    private Rectangle getAutoSize(Icon image, int size) {
        int iw = image.getIconWidth();
        int ih = image.getIconHeight();
        
        if (iw <= 0 || ih <= 0) {
            return new Rectangle(new Point(0, 0), new Dimension(size, size));
        }
        
        double scale = Math.max((double) size / iw, (double) size / ih);
        int width = (int) Math.max(1, scale * iw);
        int height = (int) Math.max(1, scale * ih);
        int x = (size - width) / 2;
        int y = (size - height) / 2;
        
        return new Rectangle(new Point(x, y), new Dimension(width, height));
    }

    /**
     * Converts any Icon to Image. Handles both ImageIcon and custom Icon implementations
     */
    private Image toImage(Icon icon) {
        if (icon == null) {
            return null;
        }
        
        if (icon instanceof ImageIcon) {
            return ((ImageIcon) icon).getImage();
        }
        
        // For custom Icon implementations, render to a BufferedImage
        try {
            int w = icon.getIconWidth();
            int h = icon.getIconHeight();
            if (w <= 0 || h <= 0) {
                return null;
            }
            
            BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = img.createGraphics();
            icon.paintIcon(this, g2, 0, 0);
            g2.dispose();
            return img;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Convenience method to set an image from a file path
     */
    public void setImage(String imagePath) {
        try {
            ImageIcon icon = new ImageIcon(imagePath);
            setIcon(icon);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Convenience method to set an image from a BufferedImage
     */
    public void setImage(BufferedImage image) {
        setIcon(new ImageIcon(image));
    }

    /**
     * Sets the border color (uses the foreground color)
     */
    public void setBorderColor(Color color) {
        setForeground(color);
    }

    /**
     * Gets the border color
     */
    public Color getBorderColor() {
        return getForeground();
    }
}
